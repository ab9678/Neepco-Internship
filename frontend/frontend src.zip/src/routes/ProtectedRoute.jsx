import { Navigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";

const ProtectedRoute = ({ children }) => {

    const { user, loading } = useAuth();

    if (loading) {

        return (

            <div className="flex min-h-screen items-center justify-center">

                Loading...

            </div>

        );

    }

    if (!user) {

        return <Navigate to="/login" replace />;

    }

    return children;

};

export default ProtectedRoute;